import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.geom.RectangularShape; 
import java.awt.geom.Rectangle2D; 
import java.awt.geom.AffineTransform; 
import java.awt.geom.*; 
import java.awt.Graphics2D.*; 
import java.awt.geom.Rectangle2D; 
import java.util.*; 
import java.awt.*; 
import java.awt.geom.Area; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PROJECTFALCON extends PApplet {












//TO DO lose state

//TEMP
final int NUMSTARS = 2000;
Star[] s;

int fcount= -1;

int before = frameCount;
int beforep = frameCount;
int beforenpc = frameCount;
float maxSpeed = 4;

ArrayList<Room> rooms = new ArrayList<Room>();
ArrayList<Pickup> thePickups = new ArrayList<Pickup>();
ArrayList <Bullet> bullets = new ArrayList <Bullet> ();
ArrayList<Bomb> bombs = new ArrayList<Bomb>();
ArrayList<NPC> NPCs = new ArrayList<NPC>();

ArrayList<Bullet>npcsBullets = new ArrayList<Bullet>();
PVector oldPos;

Player p = new Player();

//need to make more of them
Enemy e = new Enemy();


String playerDirection = "up";

String state = "menu";
//Creating image fields
PImage enemy1u;
PImage enemy1d;
PImage enemy1l;
PImage enemy1r;

PImage asteroid;

PImage gradient;
PImage gradient2;

PImage playerUp ;
PImage playerDown;
PImage playerLeft;
PImage playerRight;

public void settings() {
  size(1600, 800);
  //size(1920,1080);
}

public void setup() {

  //loading images
  enemy1u = loadImage("e1u.png");
  enemy1d = loadImage("e1d.png");
  enemy1l = loadImage("e1l.png");
  enemy1r = loadImage("e1r.png");

  asteroid = loadImage("asteroid.png");

  gradient = loadImage("gradient.png");
  gradient2 = loadImage("gradient2.png");
  playerUp = loadImage("player_up.png");
  playerDown= loadImage("player_down.png");
  playerLeft= loadImage("player_left.png");
  playerRight = loadImage("player_right.png");

  gradient.resize(width, height);

  noCursor();
  noStroke();
  
  frameRate(60);


  if (state.equals("arena2")) {
    //loading images
    enemy1u = loadImage("e2u.png");
    enemy1d = loadImage("e2d.png");
    enemy1l = loadImage("e2l.png");
    enemy1r = loadImage("e2r.png");
    p.playerPos.x = 0;
    p.playerPos.y = 0;
    p.HP +=100;
  }

  if (state.equals("arena") || state.equals("arena2")) {

    rooms.clear();
    thePickups.clear();
    bullets.clear();
    bombs.clear();
    NPCs.clear();

    createNPCs();

    //Borders around game
    //top wall
    Room r1 = new Room(-3*width, -3*width, 6*width, 200);
    //left wall
    Room r2 = new Room(-3*width, -3*width, 200, 6*width);
    //right wall
    Room r3 = new Room(3*width, -3*width, 200, 6*width+200);
    //bottom wall
    Room r4 = new Room(-3*width, 3*width, 6*width, 200);

    //Addding the rooms to the rooms arraylist
    rooms.add(r1);
    rooms.add(r2);
    rooms.add(r3);
    rooms.add(r4);


    makeRooms();
    makePickups();
    //TEMP
    s = new Star[NUMSTARS];
    for (int i = 0; i < NUMSTARS; i ++)
      s[i] = new Star();
  }
}

public void draw() { 

  //Setting drawing mode for ellipse
  ellipseMode(CORNER);

  if (state.equals("menu")) {
    //background(0);
    background(gradient2);
    
    textSize(50);
    


    if ((new Rectangle2D(width/2, height/2 -40, 280, 50).contains(mouseX, mouseY))) {
      fill(0, 155, 155);
      rect(width/2, height/2 -40, 280, 50);
    }

    fill(255, 255, 255);
    //Start Game menu text
    text("Start Game", width/2, height/2);

    textSize(20);
    fill(0, 255, 255);
    text("An arcade shoot em up by Dylan Kumar", width/4, height/5);

    fill(0, 255, 255);
    text("Click to shoot, space to fire a bomb", width/2 + width/5, height/2 + height/5);

    //Mouse cursor
    fill(255, 0, 0);

    if (mousePressed && (new Rectangle2D(width/2, height/2 -40, 280, 50).contains(mouseX, mouseY))) {
      state = "arena";
      setup();
      if (state.equals("arena")) {
      }
    }
  } else if (state.equals("dead")) {
    background(0); 
    textSize(50);
    text("You are dead", width/2, height/2);
    int i =0;
    while(i < 700000){
     i++; 
    }
    state = "menu";
  } else if (state.equals("arena2")) {
    if (p.playerPoints > 1000) {
      state = "win1";
    } else if (p.HP <= 0) {
      state = "dead";
    }

    //background(0);
    background(gradient);

    textSize(32);


    //Randomly generating enemy ever n seconds
    EnemyGeneration();


    //Buildings bulid = new Buildings(50, 50, 500, 500, 20);


    //Randomly generate a pickup every 10 seconds or so
    timedGeneration();

    //Move the NPCs in the NPCs array
    moveNPCs();



    //Player Shooting
    p.playerShoot();

    //Translation for camera
    pushMatrix();

    translations();


    //moving our player
    p.playerMovement();

    //AI/NPC shooting:
    for (NPC n : NPCs) {
      n.shoot();
    }

    //bulid.drawRoom();


    //Drawing stars for effect
    for (int i = 0; i < NUMSTARS; i ++) {
      s[i].draw();
    }


    iteration();


    drawPickups();

    drawRooms();
    p.drawPlayer();
    p.playerDamage();

    e.drawEnemy();

    e.move();


    popMatrix();

    //GUI
    fill(0, 155, 155);
    text("Ammo: " + p.blueAmmo, 10, 30); 
    fill(255, 0, 0);

    text("Bombs: " + p.bomb, 200, 30);

    text("HP: " + p.HP, 400, 30); 
    fill(255, 255, 0);
    text("Points: " + p.playerPoints, width-200, 30);
    fill(255);
    //text(frameRate, width - 50, 30);
    //text("Speed: " + (abs(p.velocity.x) + abs(p.velocity.y)), width - 500, 30);
  } else if (state.equals("arena")) {

    // FIRST LEVEL

    if (p.playerPoints > 100) {
      if (fcount == -1) { 
        fcount = frameCount;
      }
      //FIX TEXT ISSUES
      int current = frameCount - fcount;
      fill(255);
      text("YOU WIN!!!, Level 2 will begin shortly...", width/2, height/2);

      if (current >=frameRate*10) {
        state = "arena2";
        setup();
        fcount = frameCount;
      }
    } else if (p.HP <= 0) {
      state = "dead";
    } else {

      //background(0);
      background(gradient);

      textSize(32);


      //Randomly generating enemy ever n seconds
      EnemyGeneration();

      //Buildings bulid = new Buildings(50, 50, 500, 500, 20);


      //Randomly generate a pickup every 10 seconds or so
      timedGeneration();

      //Move the NPCs in the NPCs array
      moveNPCs();

      //Player Shooting
      p.playerShoot();

      //Translation for camera
      pushMatrix();

      translations();


      //moving our player
      p.playerMovement();

      //AI/NPC shooting:
      for (NPC n : NPCs) {
        n.shoot();
      }

      //bulid.drawRoom();


      //Drawing stars for effect
      for (int i = 0; i < NUMSTARS; i ++) {
        s[i].draw();
      }


      iteration();


      drawPickups();

      drawRooms();
      p.drawPlayer();
      p.playerDamage();

      e.drawEnemy();

      e.move();


      popMatrix();

      //GUI
      fill(0, 155, 155);
      text("Ammo: " + p.blueAmmo, 10, 30); 
      fill(255, 0, 0);

      text("Bombs: " + p.bomb, 200, 30);

      text("HP: " + p.HP, 400, 30); 
      fill(255, 255, 0);
      text("Points: " + p.playerPoints, width-200, 30);
      fill(255);
      //text(frameRate, width - 50, 30);
      //text("Speed: " + (abs(p.velocity.x) + abs(p.velocity.y)), width - 500, 30);
    }
  }


  ellipseMode(CENTER);
  noFill();
  stroke(255, 255, 255);
  ellipse(mouseX, mouseY, 20, 20);
  fill(255, 0, 0);
  noStroke();
  ellipseMode(CORNER);
}






// http://www.openprocessing.org/sketch/141041
class Star {
  PVector pos, target, direction, velocity;
  float size, limit;
  Star() {
    //2, 6
    size = random(2, 6f);
    if (size >= 2 && size < 8) {
      limit = random(0.1f, 0.5f);
    } else limit = random(0.5f, 1);
    direction = new PVector(0, 0);
    pos = new PVector(random(-3*width, 3*width), random(-6*height, 6*height));
    target = new PVector(3*width, pos.y);
    velocity = new PVector(0, 0);
  }

  public void draw() {
    direction = PVector.sub(target, pos);
    float separation = direction.mag();
    float distance = separation;
    direction.normalize();
    direction.mult(0.5f);
    PVector acceleration = direction;

    velocity.add(acceleration);
    velocity.limit(limit);
    pos.add(velocity);
    fill(pos.x-100, PVector.dist(target, pos), 0);

    if (p.playerPos.dist(this.pos) < width+200) { 
      stroke(255, 0, 0);
      ellipse(pos.x, pos.y, size, size);
      noStroke();
    }

    if (pos.x > 3*width) {
      direction = new PVector(0, 0);
      pos = new PVector(random(-3*width, -2*width), random(-height*3, height*3));
      target = new PVector(5*width, pos.y);
      velocity = new PVector(0, 0);
    }
  }
}


public void EnemyGeneration() {
  int current = frameCount - beforenpc;
  //after 5 seconds generate new enemy
  if (current >=frameRate*3) {

    float shootRate;
    int a = (int)random(0, 100);
    if (a < 20 && a > 5 && !state.equals("arena2")) {
      shootRate = random(frameRate, frameRate*10);
    } else if (a > 20) {
      shootRate = random(frameRate/2, frameRate/3);
    } else {
      shootRate = random(frameRate/12, frameRate/2);
      println("MONSTER SPAWNED!");
    }
    PVector npcLoc = new PVector(random(-3*width, 3*width), random(-3*height, 3*height));
    NPC npc = new NPC(npcLoc, random(0, 1), random(2, 4), (int)random(2, 50), shootRate);
    while (npc.intersectsRoom() || npc.RectangleIntersection(p) || npc.position.dist(p.playerPos) < 1000) {
      npcLoc = new PVector(random(-3*width, 3*width), random(-3*height, 3*height));
      npc = new NPC(npcLoc, random(0, 1), random(2, 4), (int)random(2, 50), shootRate);
    }
    NPCs.add(npc);

    beforenpc = frameCount;
    println("GeneratedNPC");
  }
}

public void moveNPCs() {
  for (NPC n : NPCs) {
    n.moveNPC();
    PVector lastPos = n.position.copy();
    n.moveNPC();
    if (n.intersecting == true) {
      n.position = lastPos;
    }
  }
}


public void iteration() {
  //NPCs bullets
  Iterator<Bullet> npcBulletItr = npcsBullets.iterator();
  while (npcBulletItr.hasNext()) {
    Bullet b = npcBulletItr.next();
    b.update();
    b.display();
    if (b.stillAlive() == false) {
      npcBulletItr.remove();
    }
  }

  //Using iterator as removing will break for-each loop
  Iterator<Bullet> itr = bullets.iterator();
  while (itr.hasNext()) {
    Bullet b = itr.next();
    b.update();
    b.display();
    if (!b.stillAlive()) {
      itr.remove();
    }
  }

  //Bomb iteration
  Iterator<Bomb> bombitr = bombs.iterator();
  while (bombitr.hasNext()) {
    Bomb b = bombitr.next();
    b.update();
    b.display();
    if (!b.stillAlive()) {
      bombitr.remove();
    }
  }
  //Easier better ways to do it in JAVA 8: 
  //List.removeAll(b ->!b.isAlive());
  //list.removeAll(Bomb::notAlive);

  Iterator<Pickup> Pickupitr = thePickups.iterator();
  while (Pickupitr.hasNext()) {
    Pickup currentPickup = Pickupitr.next();
    currentPickup.drawPickup();
    //If intersects with any of the ammo pickups, remove it and add ammo to player.
    if (used(currentPickup) == true) {
      if (currentPickup.type.equals("Ammo") ) {
        p.blueAmmo += 20;
      } else if (currentPickup.type.equals("Bomb")) {
        p.bomb += 5;
      }
      Pickupitr.remove();
    }
  }

  //Iterating over NPCs to see if they need to be removed
  Iterator<NPC> npcIterator = NPCs.iterator();
  while (npcIterator.hasNext()) {
    NPC n = npcIterator.next();
    //drawing NPC
    n.drawNPC();
    if (n.isAlive() == false) {
      if (n.HP > 0) {
        n.HP = n.HP - 3;
        p.playerPoints++;
      } else {
        npcIterator.remove();
        //If you kill an enemy player gets 1 HP
        p.HP++;
      }
    }
  }
}

public void createNPCs() {
  //CREATING NPC's
  while (NPCs.size() < 100) {
    float shootRate;
    int a = (int)random(0, 100);
    boolean normalMode = false;
    int n;
    if (normalMode = true) {
      n = 5;
    } else {
      n = 29;
    }
    if (a < 30 && a >= n && !state.equals("arena2")) {
      shootRate = random(frameRate/6, frameRate);
    } else if (a > 30) {
      shootRate = random(frameRate, frameRate*10);
    } else {
      shootRate = random(frameRate/12, frameRate/2);
      println("MONSTER SPAWNED!");
    }

    NPC npc = new NPC(new PVector(random(-3*width, 3*width), random(-3*height, 3*height)), random(0, 1), random(2, 4), (int)random(2, 50), shootRate);
    if (!npc.intersectsRoom() &&!npc.RectangleIntersection(p) && !npc.intersectsNPC()) {
      NPCs.add(npc);
    }
  }
}

public void translations() {

  int translationCheck = 0;

  //Translations for 4 corners of screen & near edge of screen
  if ((p.getPosition().x < -width*3 + width/2+200) &&  (p.getPosition().y > width*3 - height/2) ) {
    translate((width*3 - width/2-200), -(width*3 - height/2));
    translationCheck++;
  } else if ((p.getPosition().x < -width*3 + width/2+200) &&  (p.getPosition().y < -width*3 + height/2+200)) {
    translate((width*3 - width/2-200), (width*3 - height/2-200));
    translationCheck++;
  } else if ((p.getPosition().x > width*3 - width/2) &&  (p.getPosition().y < -width*3 + height/2+200)) {
    translate((-(width*3-width/2)), (width*3 - height/2-200));
    translationCheck++;
  } else if ((p.getPosition().x > width*3 - width/2) &&  (p.getPosition().y > width*3 - height/2) ) {
    translate((-(width*3-width/2)), -(width*3 - height/2));
    translationCheck++;
  } else
    if (p.getPosition().x < -width*3 + width/2+200) { 
      translate((width*3 - width/2 -200), -p.playerPos.y);
      translationCheck++;
    } else 
    if (p.getPosition().x > width*3 - width/2) {
      translate(-(width*3-width/2), -p.playerPos.y);
      translationCheck++;
    } else
      if (p.getPosition().y > width*3 - height/2) {
        translate(-p.playerPos.x, (-(width*3 - height/2)));
        translationCheck++;
      } else
        if (p.getPosition().y < -width*3 + height/2+200) {
          translate(-p.playerPos.x, (width*3 - height/2-200));
          translationCheck++;
        } else
          if (translationCheck == 0) {
            translate((-p.playerPos.x), (-p.playerPos.y));
          }


  translate(width/2, height/2);
}




// Cool sprites http://millionthvector.blogspot.co.nz/p/free-sprites.html
class Pickup extends Collideable {

  PVector loc;
  float Width;
  float Height;

  String type; 

  Pickup(PVector loc, float Width, float Height, String type) {
    this.loc = loc;
    this.Width = Width;
    this.Height = Height;
    this.type = type;
  }

  public float getHeight() {
    return Height;
  }
  public float getWidth() {
    return Width;
  }
  public PVector getPosition() {
    return loc;
  }

  public void drawPickup() {
    if (type.equals("Ammo")) {
      fill(0, random(0, 255), random(200, 255));
    } else {
      fill(random(250, 255), 200, 0);
    }
    //fill(0, random(random(200, 255), 255), 0);

    rect(loc.x, loc.y, Width, Height);
    fill(255);
  }
}

public void makePickups() {
  while (thePickups.size() < 20) {
    randGeneratePickup();
  }
}

public void timedGeneration() {
  int current = frameCount - beforep;
  //after 10 seconds generate new pickup
  if (current >=frameRate*5) {
    randGeneratePickup();
    beforep = frameCount;
    println("Generated");
  }
}

public void randGeneratePickup() {
  float a = random(0, 100);
  //generate pickup and check if intersecting/too close to player (don't want to randomly spawn it near it)
  PVector pLoc = new PVector(random(-3*width, 3*width), random(-3*height, 3*height));
  Pickup pick;

  if (a > 10) {
    pick = new Pickup(pLoc, 30, 30, "Ammo");
  } else {
    pick = new Pickup(pLoc, 30, 30, "Bomb");
  }

  while (pick.intersectsRoom() || pick.RectangleIntersection(p) || p.playerPos.dist(pLoc) < 1000) {
    a = random(0, 100);
    pLoc = new PVector(random(-3*width, 3*width), random(-3*height, 3*height));
    if (a > 10) {
      pick = new Pickup(pLoc, 30, 30, "Ammo");
    } else {
      pick = new Pickup(pLoc, 30, 30, "Bomb");
    }
  }
  thePickups.add(pick);
}



//TODO Randomly generate pickups

public boolean used(Pickup currentPickup) { 
  if (currentPickup.RectangleIntersection(p)) {
    return true;
  }  
  return false;
}


public void drawPickups() {
  for (Pickup pick : thePickups) {
    pick.drawPickup();
  }
}
class Enemy extends Collideable {

  PVector position = new PVector(100, 100);
  PVector directions = new PVector(1, 0);
  int turn = 0;

  float speed = 5;

  public float getHeight() {
    return 20;
  }
  public float getWidth() {
    return 20;
  }
  public PVector getPosition() {
    return position;
  }


  public void wander() {
    //Pick a random direction out of the 4 directions

    //move in that direction for random amount

    //if intersect with wall during that time, change direction

    //if end of move, then pick another direction of the 3 you didn't just go in
  }

  //public void actions() {
  //  if ( targetInRange == true )  
  //  {
  //    FireAtTarget();d
  //  } else if ( bulletComingTowardsMe == true )
  //  {
  //    MoveAwayFromBullet();
  //  } else
  //  {
  //    WanderAroundAimlessly();
  //  }
  //}

  public void move() {



    int current = frameCount - before;

    if (current >=120) {
      before = frameCount;


      //directions = new PVector(e.directions.dist(new PVector(1, 0)) == 0 ? -1: e.directions.dist(new PVector(-1, 0)) == 0 ? 1 :0, e.directions.dist(new PVector(0, 1)) == 0 ? -1: e.directions.dist(new PVector(0, -1)) == 0 ? 1 :0);

      if (turn == 0) {
        if (e.directions.dist(new PVector(1, 0)) == 0) {
          directions.x = 1;
        } else if (e.directions.dist(new PVector(1, 0)) == 0) {
          directions.x = -1;
        } else {
          directions.x = 1;
          directions.y = 1;
        }
        turn = 1;
      } else {
        if (e.directions.dist(new PVector(0, 1)) == 0) {
          directions.y = -1;
        } else if (e.directions.dist(new PVector(0, -1)) == 0) {
          directions.y = 1;
        } else {
          directions.x = -1;
          directions.y = -1;
        }
        turn = 0;
      }
    }


    PVector oldPos = position.copy();
    //position.add(directions.mult(speed));
    position.add(position.mult(directions, speed));
    if (intersectsRoom()) {
      position = oldPos;
    }
  }

  public void drawEnemy() {
    fill(255, 0, 0);
    rect(position.x, position.y, getWidth(), getHeight());
    fill(255);
  }
}

//To check if player/room, etc is in cone of vision
class Vision extends Collideable {

  PVector position;
  float vHeight;
  float vWidth;

  public float getHeight() {
    return vHeight;
  }
  public float getWidth() {
    return vWidth;
  }
  public PVector getPosition() {
    return position;
  }

  public void updatePos(float x, float y) {
    position.x = x;
    position.y = y;
  }

  Vision(PVector position, float vWidth, float vHeight) {
    this.position = position;
    this.vWidth = vWidth;
    this.vHeight = vHeight;
  }

  public boolean checkIntersection() {

    if (dist(position.x+vWidth/2, position.y+vWidth/2, p.playerPos.x, p.playerPos.y) < 450) {
      return true;
    }
    return false;
  }
}



class NPC extends Collideable {

  int beforeA = frameCount;
  int beforeB = frameCount;
  int dir = getDirection();

  PVector position;

  float upperSpeed;
  float lowerSpeed;

  int HP;
  float npcWidth;
  float npcHeight;
  double timeToShoot;

  boolean intersecting = false;

  NPC(PVector position, float lowerSpeed, float upperSpeed, int HP, double timeToShoot) {
    this.position = position;
    this.lowerSpeed = lowerSpeed;
    this.upperSpeed = upperSpeed;
    this.HP = HP;
    this.timeToShoot = timeToShoot;

    this.npcWidth = random(40, 60);
    this.npcHeight = this.npcWidth;
    //this.npcHeight = random(20, 60);
  }

  public float getHeight() {
    return npcHeight;
  }
  public float getWidth() {
    return npcWidth;
  }
  public PVector getPosition() {
    return position;
  }


  public boolean visionCheck() {
    Vision v = new Vision(new PVector(position.x, position.y), getWidth(), getHeight());
    v.updatePos(position.x, position.y);
    if (v.checkIntersection()) {
      return true;
    }
    return false;
  }

  public void shoot() {
    int currentB = frameCount - beforeB;
    if (visionCheck()) {


      if (currentB >= timeToShoot) {
        beforeB = frameCount;
        //Shoot at player
        PVector npcPos =  new PVector().set(position);
        PVector dir = PVector.sub(p.getPosition(), npcPos);
        dir.normalize();
        dir.mult(maxSpeed*3);
        Bullet bullet = new Bullet(npcPos, dir, true);
        npcsBullets.add(bullet);
        println(npcsBullets.size());
      }
    } else {
      beforeB = frameCount;
    }
  }

  public boolean isAlive() { 
    //If a bullet (or bomb) intersects the current NPC object
    if (bulletIntersectsSomething() || bombIntersectsSomething()) {
      return false;
    }  
    return true;
  }

  public int getDirection() {
    int r = (int)random(0, 4);
    //direction that's not the current one
    while (r == dir) {
      r = (int)random(0, 4);
    }
    return r;
  }

  public void moveNPC() {

    oldPos = this.position.copy();

    int currentB = frameCount - beforeB;
    if (currentB >=frameRate*3) {
      beforeB = frameCount;
      //direction that's not the current one
      this.dir = getDirection();
    }

    if (dir == 0) {
      position.x = position.x + random(lowerSpeed, upperSpeed);
    } else if (dir == 1) {
      position.x = position.x - random(lowerSpeed, upperSpeed);
    } else if (dir == 2) {
      position.y = position.y + random(lowerSpeed, upperSpeed);
    } else if (dir == 3) {  
      position.y = position.y - random(lowerSpeed, upperSpeed);
    } else {

      println("ISSUE");
    }

    if (intersectsRoom()) {
      position = oldPos;
      //if (dir == 0) {
      //  position.x = position.x - 5;
      //} else if (dir == 1) {
      //  position.x = position.x + 5;
      //} else if (dir == 2) {
      //  position.y = position.y - 5;
      //} else if (dir == 3) {
      //  position.y = position.y + 5;
      //}

      dir = getDirection();
      beforeB = frameCount;
      intersecting = true;
    } else {
      intersecting = false;
    }
  }


  public void drawNPC() {
    if (HP < 10) { 
      fill(255);
    }
    if (HP >= 10 && HP < 20) { 
      fill(255, 255, 0);
    }
    if (HP >= 20 && HP < 30) { 
      fill(252, 173, 55);
    }
    if (HP >= 30) { 
      fill(255, 0, 0);
    }

    //If not outside of window, draw it
    if (!((getPosition().x > p.getPosition().x + width || (getPosition().x) < p.getPosition().x - width) || (getPosition().y > p.getPosition().y + height) || (getPosition().y > p.getPosition().y + height))) {
      if (dir == 0) {
        //right
        image(enemy1r, position.x, position.y, getWidth(), getHeight());
      } else if (dir == 1) {
        //left
        image(enemy1l, position.x, position.y, getWidth(), getHeight());
      } else if (dir == 2) {
        //down
        image(enemy1d, position.x, position.y, getWidth(), getHeight());
      } else if (dir == 3) {  
        //up
        image(enemy1u, position.x, position.y, getWidth(), getHeight());
      }
    }





    //rect(position.x, position.y, getWidth(), getHeight());
  }
}
public class Rectangle2D {
  private float x, y, width, height;
  public Rectangle2D(float x, float y, float width, float height) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  public float getX() {
    return this.x;
  }

  public float getY() {
    return this.y;
  }

  public float getWidth() {
    return this.width;
  }

  public float getHeight() {
    return this.height;
  }

  public boolean intersects(Rectangle2D other) {
    if (x+width > other.getX() && x < other.getX() + other.getWidth() && y+height > other.getY() && y < other.getY() + other.getHeight()) {
      return true;
    } else {
      return false;
    }
  }

  public boolean contains(float x, float y) {
    if (x > this.x && x < this.x + this.width && y > this.y && y < this.y+this.height) {
      return true;
    } else {
      return false;
    }
  }
}




abstract class Collideable {

  public abstract float getWidth();
  public abstract float getHeight();
  public abstract PVector getPosition();

  public Rectangle2D getBounds() {
    return new Rectangle2D(getPosition().x, getPosition().y, getWidth(), getHeight());
  }

  public Rectangle2D RoomBounds() {
    return new Rectangle2D(getPosition().x + getWidth()/10, getPosition().y + getHeight()/10, getWidth()-getWidth()/3.7f, getHeight()-getHeight()/4.2f);
  }

  public Ellipse2D getBoundsEllipse() {
    return new Ellipse2D.Float(getPosition().x, getPosition().y, getWidth(), getHeight());
  }

  //Intersections with Areas- NOT USED, kept unless needed
  //boolean intersects(Collideable other) {
  //  if (other == this) return false;
  //  Area thisArea = new Area(getBounds());
  //  Area otherArea = new Area(other.getBounds());
  //  otherArea.intersect(thisArea);
  //  return !otherArea.isEmpty();
  //}

  //boolean bulletIntersection(Collideable other) {
  //  return (getBoundsEllipse().intersects(other.getBounds()));
  //}

  public boolean RectangleIntersection(Collideable other) {
    return (getBounds().intersects(other.getBounds()));
  }

  public boolean RoomIntersection(Collideable other) {
    return (getBounds().intersects(other.RoomBounds()));
  }

  public boolean intersectsRoom() {
    for (Room r : rooms) {
      if (RectangleIntersection(r)) return true;
    }
    return false;
  }

  public boolean intersectsNPC() {
    for (NPC n : NPCs) {
      if (RectangleIntersection(n)) return true;
    }
    return false;
  }


  public boolean bulletIntersectsRoom() {
    for (Room r : rooms) {
      if (RoomIntersection(r)) return true;
    }
    return false;
  }

  public boolean bulletIntersectsSomething() {
    for (Bullet b : bullets) {
      if (RectangleIntersection(b)) return true;
    }
    return false;
  }

  public boolean bombIntersectsSomething() {
    for (Bomb b : bombs) {
      if (RectangleIntersection(b)) return true;
    }
    return false;
  }

  public boolean bulletIntersectsPlayer() {
    for (Bullet b : npcsBullets) {
      if (RectangleIntersection(b)) return true;
    }
    return false;
  }
}
//storing all the key presses 
boolean[] keys = new boolean[10];

public void keyPressed()
{  
  if (key == 'd' || key == 'D')
  {
    keys[0]=true;
    playerDirection = "right";
  }

  if (key == 'a' || key == 'A' )
  {
    keys[1]=true;
    playerDirection = "left";
  }

  if (key == 's' || key == 'S')
  {
    keys[2]=true;
    playerDirection = "down";
  }

  if (key == 'w' || key == 'W')
  {
    keys[3]=true;
    playerDirection = "up";
  }

  if (key == 'q')
  {
    keys[4]=true;
  }

  if (key == 'e')
  {
    keys[5]=true;
  }

  if (keyCode == SHIFT || key == ' ') {
    keys[6] = true;
  }
  
  //Space for boost
  if (key == ' ') {
    keys[7] = true;
    //p.speed = 5;
    p.speed = 25;
  }

 }

public void keyReleased()
{
  if (key == 'd' || key == 'D')
  {
    keys[0]=false;
  }

  if (key == 'a' || key == 'A')
  {
    keys[1]=false;
  }

  if (key == 's' || key == 'S')
  {
    keys[2]=false;
  }

  if (key == 'w' || key == 'W')
  {
    keys[3]=false;
  }

  if (key == 'q')
  {
    keys[4]=false;
  }

  if (key == 'e')
  {
    keys[5]=false;
  }

  if (keyCode == SHIFT || key == ' ') {
    keys[6] = false;
  }

  if (key == ' ') {
    keys[7] = false;
    p.speed = p.baseSPEED;
  }
} 
class Bomb extends Collideable {

  PVector loc;
  PVector vel;

  float bombHeight = 20;
  float bombWidth = 20;
  boolean exploded = false;

  public float getHeight() {
    return bombHeight;
  }
  public float getWidth() {
    return bombWidth;
  }

  public PVector getPosition() {
    return loc;
  }

  Bomb(PVector loc, PVector vel) {
    this.loc = loc;
    this.vel = vel;
  }

  public boolean stillAlive() {
    if ((bombWidth <= 0) || (bombHeight <= 0)) {
      return false;
    }
    return true;
  }

  public void update() {
    
    //So that the width/height isn't always reset to 200 when another collision occurs
    if (!exploded && (bulletIntersectsRoom() || intersectsNPC())) {
      bombWidth = 200;
      bombHeight = 200;
      loc.x = loc.x - 100;
      loc.y = loc.y - 100;
    } 
    
    if (bulletIntersectsRoom() || intersectsNPC()) {
      vel.x = 0;
      vel.y = 0;
      exploded = true;
    }
    
    if (exploded) {
      loc.x +=0.5f;
      loc.y +=0.5f;
      bombWidth--;
      bombHeight--;
    }
    loc.add(vel);
  }

  public void display() {
    //ellipseMode(CENTER);
    fill(random(200,255), random(100, 255), 0);
    ellipse(loc.x, loc.y, bombWidth, bombHeight);
    //ellipseMode(CORNER);
  }
}


class Bullet extends Collideable {

  PVector vel;
  PVector loc;
  boolean deadly;
  String type = "bomb";

  int beforeB = frameCount;

  Bullet(PVector loc, PVector vel, boolean deadly) {
    this.loc = loc;
    this.vel = vel;
    this.deadly = deadly;
  }

  public void update() {
    if (bulletIntersectsRoom()) {
      this.vel.set(vel.mult(-1));
      //this.vel.y = this.vel.y*-1;
    }
    loc.add(vel);
  }

  public void display() {
    if (!deadly) {
      fill(0, random(100, 255), random(200, 255));
    } else {
      //fill(255, 0, 0);
      fill(255);
    }
    ellipse(loc.x, loc.y, 5, 5);
    fill(255);
  }

  public boolean stillAlive() {
    // Delete bullet after time
    int currentB = frameCount - beforeB;
    if (currentB >=frameRate*4) {
      beforeB = frameCount;
      return false;
    }
    return true;
  }

  public void removeBullet() {
    bullets.remove(this);
  }

  public float getHeight() {
    return 5;
  }
  public float getWidth() {
    return 5;
  }

  public PVector getPosition() {
    return loc;
  }
}
class Player extends Collideable {

  private float speed = 2;
  private PVector sp;
  private float baseSPEED = speed;

  private PVector velocity = new PVector(0, 0);
  private float acceleration = 0.5f;

  private PVector playerPos = new PVector(0, 0);

  private float HP = 100;
  private double playerPoints = 0;

  private int blueAmmo = 20;
  private int bomb = 5;



  //TODO make clipping for player smaller

  int beforeBomb = frameCount;

  PImage playerImg;

  PVector rotation;

  float rotationAngle = .05f;
  float theta;

  public void playerShoot() {

    PVector mouse = new PVector(mouseX+p.playerPos.x-((width/2)), mouseY+p.playerPos.y-(height/2));

    if (frameCount%5==0 && mousePressed && p.blueAmmo > 0 ) {

      PVector playerCoord =  new PVector().set(p.getPosition());
      playerCoord.x = playerCoord.x + 25;
      playerCoord.y = playerCoord.y + 25;

      PVector dir = PVector.sub(mouse, playerCoord);
      dir.normalize();
      dir.mult(maxSpeed*3);
      Bullet b = new Bullet(playerCoord, dir, false);
      bullets.add(b);
      blueAmmo--;
    }

    if (keys[6] == true && bomb > 0) {
      int currentB = frameCount - beforeBomb;
      //3 second delay before you can shoot a bomb again
      if (currentB >=frameRate*3) {
        beforeBomb = frameCount;

        PVector playerCoord =  new PVector().set(p.getPosition());
        playerCoord.x = playerCoord.x + 25;
        playerCoord.y = playerCoord.y + 25;

        PVector dir = PVector.sub(mouse, playerCoord);
        dir.normalize();
        float bombSpd = max(abs(p.velocity.x), abs(p.velocity.y));
        if(bombSpd < 5){
           bombSpd = 5; 
        }
        dir.mult(bombSpd);
        Bomb b = new Bomb(playerCoord, dir);
        bombs.add(b);
        bomb--;
        //reduce bomb ammo
      }
    }
  }


  public void playerDamage() {
    if (bulletIntersectsPlayer()) {
      HP = HP - 0.5f;
      baseSPEED = baseSPEED + 0.1f;
      if (!keyPressed) {
        speed = baseSPEED;
      }
    }
  }

  public Player() {
    rotation = new PVector(0, 1);
  }

  public void drawPlayer() {
    //rect(playerPos.x, playerPos.y, getWidth(), getHeight());


    if (playerDirection.equals("up") && keys[1]==true) { 
      image(playerLeft, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("up") && keys[0]==true) { 
      image(playerRight, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("down") && keys[0]==true) { 
      image(playerRight, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("down") && keys[1]==true) { 
      image(playerLeft, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("left") && keys[3] == true) { 
      image(playerUp, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("right") && keys[3] == true) { 
      image(playerUp, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("up")) { 
      image(playerUp, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("left") && keys[2] == true) { 
      image(playerDown, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("right") && keys[2] == true) { 
      image(playerDown, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("down")) { 
      image(playerDown, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("left")) { 
      image(playerLeft, playerPos.x, playerPos.y, getWidth(), getHeight());
    } else if (playerDirection.equals("right")) { 
      image(playerRight, playerPos.x, playerPos.y, getWidth(), getHeight());
    }


    //theta = heading2D(rotation)  + PI/2;
    //theta += PI;

    //pushMatrix();
    //translate(playerPos.x, playerPos.y);
    //rotate(theta);
    //fill(0);

    //image(playerDown, playerPos.x, playerPos.y, getWidth(), getHeight());
    ////image(img, -r, -r*1.5, 2*r, 3*r);
    //popMatrix();
    //PVector mouse = new PVector(mouseX+p.playerPos.x-((width/2)), mouseY+p.playerPos.y-(height/2));



    //ellipse(playerPos.x, playerPos.y, 66, 66);
    //pushMatrix();
    //update(mouseX, mouseY);
    //rotate(theta);
    //image(playerDown, playerPos.x, playerPos.y, getWidth(), getHeight());

    //pMatrix();
  }

  public void update(int mx, int my) {
    theta = atan2(my-playerPos.y, mx-playerPos.x);
  }

  public void move(PVector oldPos) {
    if (intersectsRoom()) {
      playerPos = oldPos;
      velocity.x = -velocity.x/2;
      velocity.y = -velocity.y/2;
      //speed = baseSPEED;
    } 
    //else {
    //  speed = speed + 0.01*0.11;
    //  //If space is pressed turn on boost
    //  if (keys[7] == true ) {
    //     speed = speed + 0.03*0.1;
    //  }
    //}
  }

  public float getHeight() {
    return 100;
  }

  public float getWidth() {
    return 100;
  }
  public PVector getPosition() {
    return playerPos;
  }

  public void playerMovement() {

    //TODO if you hit the wall you go flying in the opposite direction


    //saving the old position of the player
    oldPos = this.playerPos.copy();

    //moving frame

    //float easing = 0.02;

    //if ( keys[3]==true) {
    //  float targetX = mouseX+p.playerPos.x-((width/2));
    //  float dx = targetX - playerPos.x;
    //  playerPos.x += dx * easing;

    //  float targetY = mouseY+p.playerPos.y-(height/2);
    //  float dy = targetY - playerPos.y;
    //  playerPos.y += dy * easing;
    //}

    //if (keys[0]==true) {

    //  rotate2D(rotation, -rotationAngle);
    //}
    //if (keys[1]== true) {
    //  rotate2D(rotation, rotationAngle);
    //}

    //if (keys[2] == true) {
    //  playerPos.x = playerPos.x- cos(radians(theta));
    //  playerPos.y = playerPos.y - sin(radians(theta));
    //}

    //speed = acceleration;


    //speed.x = speed.x;
    boolean moving = false;


    if (keys[0]==true) {
      velocity.x = velocity.x+acceleration;
      moving = true;
    } 
    if (keys[1]==true) {
      velocity.x = velocity.x -acceleration;
      moving = true;
    }
    if (keys[2]==true) {
      velocity.y = velocity.y +acceleration;
      moving = true;
    }
    if (keys[3]==true) {
      velocity.y = velocity.y -acceleration;
      moving = true;
    }


    //if(!moving){
    //   velocity.x = velocity.x - acceleration;
    //   velocity.y = velocity.y - acceleration;
    //}

    //slowing you down if you aren't moving
    //if (!moving && (velocity.x > 0)) {
    //  velocity.x = velocity.x - acceleration;
    //}
    //if (!moving && (velocity.y > 0)) {
    //  velocity.y = velocity.y - acceleration;
    //}
    //if (!moving && (velocity.x < 0)) {
    //  velocity.x = velocity.x + acceleration;
    //}
    //if (!moving && (velocity.y < 0)) {
    //  velocity.y = velocity.y + acceleration;
    //}

    if (velocity.x > 12) {
      velocity.x = 12;
    }

    if (velocity.y > 12) {
      velocity.y = 12;
    }

    if (velocity.x < -12) {
      velocity.x = -12;
    }
    if (velocity.y < -12) {
      velocity.y = -12;
    }

    print(velocity);
    p.playerPos.x = p.playerPos.x + velocity.x;
    p.playerPos.y = p.playerPos.y + velocity.y;

    //if (keys[1]==true) p.playerPos.x = p.playerPos.x + velocity.x;
    //if (keys[2]==true) p.playerPos.y = p.playerPos.y  + velocity.y;
    //if (keys[3]==true) p.playerPos.y  = p.playerPos.y  + velocity.y;


    //if (keys[0]==true) p.playerPos.x = p.playerPos.x + p.speed;
    //if (keys[1]==true) p.playerPos.x = p.playerPos.x - p.speed;
    //if (keys[2]==true) p.playerPos.y = p.playerPos.y  + p.speed;
    //if (keys[3]==true) p.playerPos.y  = p.playerPos.y  - p.speed;
    //if (keys[4]==true) rotate(0.1);
    //if (keys[5]==true) rotate(-0.1);

    //If the player is intersecting something else after being moved, move it back.
    this.move(oldPos);
  }
}
class Buildings extends Collideable {

  float x;
  float y; 

  float xMiddle;
  float yMiddle;

  float roomWidth;
  float roomHeight;
  float wallThickness;

  Buildings(float x, float y, float roomWidth, float roomHeight, float wallThickness) {
    this.x = x;
    this.y = y;
    this.roomWidth = roomWidth;
    this.roomHeight = roomHeight;  
    this.wallThickness = wallThickness;
  }

  public float getHeight() {
    return roomHeight;
  }
  public float getWidth() {
    return roomWidth;
  }
  public PVector getPosition() {
    return new PVector(x, y);
  }

  public void drawRoom() {
    //Top Wall
    rect(x, y, roomWidth+wallThickness, wallThickness);
    //Bottom Wall
    rect(x, roomHeight+y, roomWidth+wallThickness, wallThickness);
    //Left Wall
    rect(x, y, wallThickness, roomHeight);
    //Right Wall
    rect(x+roomWidth, y, wallThickness, roomHeight);
  }
}


class Room extends Collideable {
  float x;
  float y; 
  float roomWidth;
  float roomHeight;
  String roomType;
  float doorEnd;
  float doorStart;

  Room(float x, float y, float roomWidth, float roomHeight) {
    this.x = x;
    this.y = y;
    this.roomWidth = roomWidth;
    this.roomHeight = roomHeight;
  }

  public float getHeight() {
    return roomHeight;
  }
  public float getWidth() {
    return roomWidth;
  }
  public PVector getPosition() {
    return new PVector(x, y);
  }

  public void drawRoom() {
    //fill(random(200, 255), random(250, 255), random(250, 255));

    //rect(getPosition().x + getWidth()/10, getPosition().y + getHeight()/10, getWidth()-getWidth()/3.7, getHeight()-getHeight()/4.2);
    image(asteroid, x, y, roomWidth, roomHeight);

    //rect(x, y, roomWidth, roomHeight);
    fill(255);
  }
}

public void makeRooms() {
  while (rooms.size() < 200) {
    Room newRoom = new Room(random(-3*width, 3*width), random(-3*width, 3*width), random(30, 200), random(30, 200));
    while (newRoom.intersectsRoom() || newRoom.RectangleIntersection(p)) {
      newRoom = new Room(random(-3*width, 3*width), random(-3*width, 3*width), random(30, 200), random(30, 200));
    }
    rooms.add(newRoom);
  }
}

public void drawRooms() {
  for (Room r : rooms) {
    if (r.getPosition().x > p.getPosition().x + width) {
      continue;
    }
    if (r.getPosition().x < p.getPosition().x - width) {
      continue;
    }
    if (r.getPosition().y > p.getPosition().y + height) {
      continue;
    }
    if (r.getPosition().y > p.getPosition().y + height) {
      continue;
    }
    r.drawRoom();
  }
}











//private boolean isInside(PVector a, PVector b, PVector c) {
//        //Calculate the determinant of the vectors, and use it to work out what side the line is on
//        //-1 on left size
//        //0 on line
//        //+1 on right side.
//        return (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x) > 0;
//    }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PROJECTFALCON" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
